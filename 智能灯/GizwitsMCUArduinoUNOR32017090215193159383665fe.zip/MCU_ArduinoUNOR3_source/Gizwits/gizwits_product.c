/**
************************************************************
* @file         gizwits_product.c
* @brief        Gizwits 控制协议处理,及平台相关的硬件初始化 
* @author       Gizwits
* @date         2016-09-05
* @version      V03010101
* @copyright    Gizwits
* 
* @note         机智云.只为智能硬件而生
*               Gizwits Smart Cloud  for Smart Products
*               链接|增值ֵ|开放|中立|安全|自有|自由|生态
*               www.gizwits.com
*
***********************************************************/

#include <stdio.h>
#include <string.h>
#include "gizwits_product.h"
#include "gizwits_protocol.h"

/**@name Gizwits 用户API接口
* @{
*/

extern dataPoint_t currentDataPoint;
attrFlags_t attrFlags;
extern wifiStatueFlags_t wifiStatueFlags;
/**
* @brief 事件处理接口

* 说明：

* 1.用户可以对WiFi模组状态的变化进行自定义的处理

* 2.用户可以在该函数内添加数据点事件处理逻辑，如调用相关硬件外设的操作接口

* @param[in] info : 事件队列
* @param[in] data : 协议数据
* @param[in] len : 协议数据长度
* @return NULL
* @ref gizwits_protocol.h
*/
int8_t gizwitsEventProcess(eventInfo_t *info, uint8_t *data, uint32_t len)
{
  uint8_t i = 0;
  dataPoint_t *dataPointPtr = (dataPoint_t *)data;
  moduleStatusInfo_t *wifiData = (moduleStatusInfo_t *)data;
  protocolTime_t *ptime = (protocolTime_t *)data;

  if((NULL == info) || (NULL == data))
  {
    return -1;
  }

  for(i=0; i<info->num; i++)
  {
    switch(info->event[i])
    {
      case EVENT_LED_ONOFF:
        currentDataPoint.valueLED_OnOff = dataPointPtr->valueLED_OnOff;
        attrFlags.flagLED_OnOff = 1;
        break;

      case EVENT_LED_COLOR:
        currentDataPoint.valueLED_Color = dataPointPtr->valueLED_Color;
        attrFlags.flagLED_Color = 1;
        break;

      case EVENT_LED_R:
        currentDataPoint.valueLED_R = dataPointPtr->valueLED_R;
        attrFlags.flagLED_R = 1;
        //user handle
        break;
      case EVENT_LED_G:
        currentDataPoint.valueLED_G = dataPointPtr->valueLED_G;
        attrFlags.flagLED_G = 1;
        //user handle
        break;
      case EVENT_LED_B:
        currentDataPoint.valueLED_B = dataPointPtr->valueLED_B;
        attrFlags.flagLED_B = 1;
        //user handle
        break;


      case WIFI_SOFTAP:
        wifiStatueFlags.flagWifi_softap = 1;
        break;
      case WIFI_AIRLINK:
        wifiStatueFlags.flagWifi_airlink = 1;
        break;
      case WIFI_STATION:
        wifiStatueFlags.flagWifi_station = 1;
        break;
      case WIFI_CON_ROUTER:
        wifiStatueFlags.flagWifi_con_router = 1;
        break;
      case WIFI_DISCON_ROUTER:
        wifiStatueFlags.flagWifi_discon_router = 1;
        break;
      case WIFI_CON_M2M:
        wifiStatueFlags.flagWifi_con_m2m = 1;
        break;
      case WIFI_DISCON_M2M:
        wifiStatueFlags.flagWifi_discon_m2m = 1;
        break;
      case WIFI_RSSI:
        break;
      case TRANSPARENT_DATA:
        break;
      case WIFI_NTP:

        //GIZWITS_LOG("WIFI_NTP : [%d-%d-%d %02d:%02d:%02d][%d] \n",ptime->year,ptime->month,ptime->day,ptime->hour,ptime->minute,ptime->second,ptime->ntp);

        break;
      default:
        break;
    }
  }

  return 0;
}





/**
* @brief MCU复位函数

* @param none
* @return none
*/
void mcuRestart(void)
{

}


