/***************************************************************

Name:		Gizwits + ArduinoUnoWiFi Library 
Author:		bing@arduino.org.cn
Version:	V1.0
Time:		2016-09-06

****************************************************************/
#include "Gizwits.h"
#include <Arduino.h>

wifiStatueFlags_t wifiStatueFlags;


Gizwits::Gizwits()
{
	memset((uint8_t*)&currentDataPoint, 0, sizeof(dataPoint_t));
}

Gizwits::~Gizwits()
{
	return;
}

void Gizwits::begin(void)
{ 
	Serial.begin(9600);
	gizwitsInit();
}

/**
* @brief 串口写操作，发送数据到WiFi模组
*
* @param buf      : 数据地址
* @param len       : 数据长度
*
* @return : 正确返回有效数据长度;-1，错误返回
*/
int32_t uartWrite(uint8_t *buf, uint32_t len)
{
    uint32_t i = 0;
    
    if(NULL == buf)
    {
        return -1;
    }
    
    for(i=0; i<len; i++)
    {
        Serial.write(buf[i]);
        //实现串口发送函数,将buf[i]发送到模组
        if(i >=2 && buf[i] == 0xFF)
        {
          //实现串口发送函数,将0x55发送到模组
            Serial.write(0x55);
        }
    }
    return len;
}

/*void serialEvent(void)
{
	uint8_t value = 0;
	value = (unsigned char)Serial.read();
	gizPutData(&value, 1);
}*/


void Gizwits::process(void)
{
	uint8_t readChar = 0;
    uint16_t i=0,num = 0;
    num = Serial.available();
    if(0 < num)
    {
        for(i=0; i<num; i++)
        {
            readChar = Serial.read();
            gizPutData(&readChar, 1);
        }
        
    }
	gizwitsHandle((dataPoint_t *)&currentDataPoint);
}

bool Gizwits::wifiHasBeenSet(EVENT_TYPE_T eventType)
{
	bool flag;
	switch(eventType)
	{
			case WIFI_SOFTAP:
				flag = 	wifiStatueFlags.flagWifi_softap;
				wifiStatueFlags.flagWifi_softap = 0;
			break;
			case WIFI_AIRLINK:
				flag = 	wifiStatueFlags.flagWifi_airlink;
				wifiStatueFlags.flagWifi_airlink = 0;
			break;
			case WIFI_STATION:
				flag = 	wifiStatueFlags.flagWifi_station;
				wifiStatueFlags.flagWifi_station = 0;
			break;
			case WIFI_CON_ROUTER:
				flag = 	wifiStatueFlags.flagWifi_con_router;
				wifiStatueFlags.flagWifi_con_router = 0;
			break;
			case WIFI_DISCON_ROUTER:
				flag = 	wifiStatueFlags.flagWifi_discon_router;
				wifiStatueFlags.flagWifi_discon_router = 0;
			break;
			case WIFI_CON_M2M:
				flag = 	wifiStatueFlags.flagWifi_con_m2m;
				wifiStatueFlags.flagWifi_con_m2m = 0;
			break;
			case WIFI_DISCON_M2M:
				flag = 	wifiStatueFlags.flagWifi_discon_m2m;
				wifiStatueFlags.flagWifi_discon_m2m = 0;
			break;
			default:
			break;
	}
	
	return flag;
}

void Gizwits::setBindMode(uint8_t mode)
{
	gizwitsSetMode(mode);
}


/** The Structure of the current device status **/
dataPoint_t currentDataPoint;
attrFlags_t attrFlags;

void Gizwits::read(EVENT_TYPE_T eventType, bool* value)
{
	switch(eventType)
	{
	      case EVENT_LED_ONOFF:
	        *value = currentDataPoint.valueLED_OnOff;
	        break;
		default:
			break;
	}
	
	return;
}

void Gizwits::read(EVENT_TYPE_T eventType, uint32_t* value)
{
	switch(eventType)
	{
	      case EVENT_LED_COLOR:
	        *value = currentDataPoint.valueLED_Color;
	        break;
	      case EVENT_LED_R:
	        *value = currentDataPoint.valueLED_R;
	        break;
	      case EVENT_LED_G:
	        *value = currentDataPoint.valueLED_G;
	        break;
	      case EVENT_LED_B:
	        *value = currentDataPoint.valueLED_B;
	        break;
		default:
			break;
	}
	
	return;
}
void Gizwits::read(EVENT_TYPE_T eventType, int32_t* value)
{
	switch(eventType)
	{
	      case EVENT_LED_COLOR:
	        *value = currentDataPoint.valueLED_Color;
	        break;
	      case EVENT_LED_R:
	        *value = currentDataPoint.valueLED_R;
	        break;
	      case EVENT_LED_G:
	        *value = currentDataPoint.valueLED_G;
	        break;
	      case EVENT_LED_B:
	        *value = currentDataPoint.valueLED_B;
	        break;
		default:
			break;
	}
	
	return;
}
void Gizwits::read(EVENT_TYPE_T eventType, float* value)
{
	switch(eventType)
	{
	      case EVENT_LED_COLOR:
	        *value = currentDataPoint.valueLED_Color;
	        break;
	      case EVENT_LED_R:
	        *value = currentDataPoint.valueLED_R;
	        break;
	      case EVENT_LED_G:
	        *value = currentDataPoint.valueLED_G;
	        break;
	      case EVENT_LED_B:
	        *value = currentDataPoint.valueLED_B;
	        break;
		default:
			break;
	}
	
	return;
}

void Gizwits::readBinary(EVENT_TYPE_T eventType, uint8_t* data)
{
	switch(eventType)
	{
		default:
			break;
	}
	
	return;
}

bool Gizwits::hasBeenSet(EVENT_TYPE_T eventType)
{
	bool flag;
	switch(eventType)
	{
			case EVENT_LED_ONOFF:
				flag = 	attrFlags.flagLED_OnOff;
				attrFlags.flagLED_OnOff = 0;
				break;
			case EVENT_LED_COLOR:
				flag = 	attrFlags.flagLED_Color;
				attrFlags.flagLED_Color = 0;
				break;
			case EVENT_LED_R:
				flag = 	attrFlags.flagLED_R;
				attrFlags.flagLED_R = 0;
				break;
			case EVENT_LED_G:
				flag = 	attrFlags.flagLED_G;
				attrFlags.flagLED_G = 0;
				break;
			case EVENT_LED_B:
				flag = 	attrFlags.flagLED_B;
				attrFlags.flagLED_B = 0;
				break;
		default:
			break;
	}
	
	return flag;
}
void Gizwits::write(VALUE_TYPE_T valueType, bool value)
{
	switch(valueType)
	{
		default:
			break;
	}
	return;
}

void Gizwits::write(VALUE_TYPE_T valueType, uint32_t value)
{
	switch(valueType)
	{
		default:
			break;
	}

	return;
}
void Gizwits::write(VALUE_TYPE_T valueType, int32_t value)
{
	switch(valueType)
	{
		default:
			break;
	}

	return;
}
void Gizwits::write(VALUE_TYPE_T valueType, float value)
{
	switch(valueType)
	{
		default:
			break;
	}

	return;
}
void Gizwits::writeBinary(VALUE_TYPE_T valueType, uint8_t* data,uint32_t dataLen)
{
	switch(valueType)
	{
		default:
			break;
	}
	
	return;
}

/**@} */

/**
* @brief 读取系统时间毫秒计时数

* @param none
* @return 系统时间毫秒数
*/
uint32_t gizGetTimerCount(void)
{
  return millis();
}